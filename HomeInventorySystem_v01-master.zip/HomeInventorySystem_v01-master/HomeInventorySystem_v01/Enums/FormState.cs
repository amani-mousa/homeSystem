﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeInventorySystem_v01.Enums
{
    enum FormState
    {
        Add =  0,
        WaitingToSave = 1,
        WaitingToSaveOrDelete = 2
    }
}
